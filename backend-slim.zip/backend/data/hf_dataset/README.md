# Code-Mixed (Hinglish) Benchmark — Datasheet

**Source:** synthetic seed expanded from 60 Hinglish prompts across 5 task categories.
**Benchmark size:** 50 rows
**Calibration size:** 0
**Pricing date:** 2026-08-28
**Collection method:** synthetic generation from curated Hinglish templates + heuristic fluff injection (clearly labelled `is_synthetic=true`).
**Consent:** no real user data; all rows are synthetic. Real-user pilot data will be consented and anonymized separately.
**Grading protocol:** reference answers are templated checkable answers; task_success computed via BLEU/ROUGE-L/fuzzy ratio.
**Known limitations:** synthetic distribution does not replace real WhatsApp/support traffic; tokenizer numbers are whitespace/heuristic when HF tokenizers not installed.
**License:** CC-BY-4.0 recommended for release.

## Usage
```python
# local JSONL
import json
rows = [json.loads(l) for l in open("benchmark.jsonl")]
# HF datasets (when installed):
# from datasets import load_dataset
# ds = load_dataset("json", data_files="benchmark.jsonl")["train"]
```

Exported: 2026-08-29
